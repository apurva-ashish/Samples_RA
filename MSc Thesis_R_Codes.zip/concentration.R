#####size proxy 

library(tidyverse)

d11 <- d11 %>% 
  group_by(RutProveedor) %>% 
  mutate(total_win = sum(MontoLineaAdjudica)) %>% 
  mutate(num_win = n()) %>% 

d12 <- d12 %>% 
  group_by(RutProveedor) %>% 
  mutate(total_win = sum(MontoLineaAdjudica)) %>% 
  mutate(num_win = n()) %>% 

View(d11[1:100,])

hist(d11$num_win)
hist(log(d12$num_win))
mean(d11$num_win)

help11 <- data.frame(d11$RutProveedor,d11$num_win,d11$total_win) %>% 
 distinct(rut = d11.RutProveedor, .keep_all = TRUE) %>% 
  mutate(small = ifelse(d11.num_win <= 5,1,0))

help12 <- data.frame(d12$RutProveedor,d12$num_win,d12$total_win) %>% 
  distinct(rut = d12.RutProveedor, .keep_all = TRUE) %>% 
  mutate(small = ifelse(d12.num_win <= 5,1,0))

help <- full_join(help11,help12, by = "rut")

help[,c("d11.num_win","d12.num_win","d11.total_win","d12.total_win")][is.na(help[,c("d11.num_win","d12.num_win","d11.total_win","d12.total_win")])] <- 0
help[,"small.x"][is.na(help[,"small.x"])] <- 1
 

ggplot(help) +
  geom_point(aes(x = log(d11.num_win), y = log(d12.num_win)))

mean(help$d11.num_win["small.x" == 1])

mean(help$d12.num_win)

mean(help[help$small.x == 1,]$d11.num_win, na.rm = TRUE)
mean(help[help$small.x == 1,]$d12.num_win, na.rm = TRUE)

mean(help[help$small.x == 0,]$d11.num_win, na.rm = TRUE)
mean(help[help$small.x == 0,]$d12.num_win, na.rm = TRUE)

summary(lm(d12.num_win ~ small.x + d11.num_win, help))

summary(lm(d12.num_win - d11.num_win ~ small.x, help))

normalize(nums)

diffs <- scale(help$d12.num_win) - scale(help$d11.num_win)
mean(diffs)

mean(help$d11.num_win)
mean(help$d12.num_win)

#############HHI 

help$sqsh11 <- (help$d11.num_win/dim(d11)[[1]])^2
help$sqsh12 <- (help$d12.num_win/dim(d12)[[1]])^2


hhi11 <- sum(help$sqsh11)
hhi12 <- sum(help$sqsh12)

hhi12/hhi11

dim(d11)[[1]]

#########Concentration ratio 



shares11 <- sort(unlist(help11$d11.num_win/dim(d11)[[1]]),decreasing = TRUE)
shares12 <- sort(unlist(help12$d12.num_win/dim(d12)[[1]]),decreasing = TRUE)

cr11 <- cumsum(shares11)
cr12 <- c(cumsum(shares12),rep(1,length(shares11) - length(shares12)))

cscreen <- data.frame(n = 1:length(cr11), con11 = cr11, con12 = cr12)
cscreen$diff <- cscreen$con11 - cscreen$con12

ggplot(slice(cscreen,seq(1,dim(cscreen)[[1]], by = 500))) +
  geom_line(aes(x = n, y = diff))

##########Entropy index (Hexter & Snow, 1970)

entropy11 <- cr11 * log(1/cr11)
entropy12 <- cr12 * log(1/cr12)
sum(entropy11)
sum(entropy12)
