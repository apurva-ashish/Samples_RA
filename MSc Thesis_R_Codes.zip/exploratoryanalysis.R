hist(t["CantidadReclamos" ])

colnames(t)

hist(t["CantidadReclamos"])

any(t["Etapas"] != t["EstadoEtapas"])

t[which(t["Etapas"] != t["EstadoEtapas"])]


test <- t["Etapas"] != t["EstadoEtapas"]
sum(test)

which(test == 1)

View(t[c(58274,58275,58276),])

tipo <- t["CodigoTipo"]
tipoc <- t["TipoConvocatoria"]

z <- ifelse(tipo == 1, 1,0)

test <- (z == tipoc)

indexes <- which(test == 0)

View(t[indexes,])
View(t)
View(t[1:100,])
View(t[c("MontoEstimado","Monto.Estimado.Adjudicado"),])


cov(t["TomaRazon"],t["MontoEstimado"])

test1 <- t["TomaRazon"]

t["TomaRazon"]

data <- read.csv("BSE/Masters Project/finished_sampled_files/2016_sampled.csv")
t <- data
test1 <- t[["TomaRazon"]]
test2 <- t[["MontoEstimado"]]

test <- t[["MontoEstimado"]]


##Convert scientific notation to simply numbers
t["MontoEstimado"] <- as.numeric(gsub(",",".",t[["MontoEstimado"]]))


cov(test1,test2)
      

any(is.na(test2))
which(is.na(test2))

print

test[40493]

any(is.na(data["MontoEstimado"]))

testdf <- data.frame(test1,test2)

testdf <- testdf[complete.cases(testdf), ]

test3 <- log(testdf[,2])
hist(test3)
cor(testdf[,1],testdf[,2])

mean(testdf[,])

mean(testdf[testdf[,1] == 0,2])

testdf[,2] 

hist(testdf[,2])

testdf <- cbind(testdf,test3)
mean(testdf[,2])

razon <-hist(testdf[testdf[,1] == 1,3])
norazon <-hist(testdf[testdf[,1] == 0,3]) 

sum(testdf[,1])

View(t[t["TomaRazon" == 1],])

View(subset(t,TomaRazon == 1))

montosum_df <- t[,c("Codigo","Correlativo","CodigoOrganismo","MontoEstimado","Monto.Estimado.Adjudicado")]

View(t[1:400,])

names1 <- names(data)
names2 <- names(t)

names1[!names1 %in% names2]
