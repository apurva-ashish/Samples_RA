wdata <- data

wdata <- wdata %>% 
  subset(Estimacion == 2) %>% 
  mutate(MontoEstimado = as.numeric(gsub(",",".",MontoEstimado))) %>% 
  mutate(profit = (as.numeric(MontoLineaAdjudica) - as.numeric(MontoEstimado )) / as.numeric(MontoEstimado)) %>% 
  subset(MontoEstimado >= 100) %>% 
  subset(as.numeric(MontoLineaAdjudica) < as.numeric(MontoEstimado*20 ))

names <- names(wdata)

nums = c()
for(i in names){
  if(class(wdata[[i]]) == "integer" | class(wdata[[i]]) == "numeric" ){
    nums = c(nums,i)
  }
}


numdata <- wdata[, nums]
numdata <- numdata[, !colnames(numdata) %in% c("X","Codigo","FechaCreacion","Codigoitem")]
sum(is.na(wdata$profit))

summary(lm(profit ~ NumeroOferentes, wdata ))

mean(wdata$profit)

hist(wdata[["profit"]])

test <- wdata %>% 
  select(c("profit","MontoEstimado","MontoLineaAdjudica"))


###is single line 

single <- wdata %>% group_by(Codigo) %>%  filter(n() == 1)

hist(single[["profit"]])
mean(single$profit)
summary(lm(profit ~ NumeroOferentes, single))
