###checking difference in bids 
library(tidyverse)

single_item <- data %>% 
  subset(Oferta.seleccionada == "Seleccionada") %>% 
  subset(Tipo %in% c("LR","LQ","LP","LE","L1")) %>% 
  group_by(Codigo) %>%  filter(n() == 1 )

single_codes <- single_item[["Codigo"]]

final_data <- subset(data, Codigo %in% single_codes)


final_data <- data %>% 
  mutate(FechaCreacion = as.numeric(as.Date(FechaCreacion))) %>% 
  mutate(FechaCierre = as.numeric(as.Date(FechaCierre))) %>%
  mutate(FechaInicio = as.numeric(as.Date(FechaInicio))) %>% 
  mutate(FechaFinal = as.numeric(as.Date(FechaFinal))) %>% 
  mutate(MontoLineaAdjudica = as.numeric(data[["MontoLineaAdjudica"]])) %>%
  subset(Codigo %in% single_codes) %>% 
  mutate(length = FechaCierre - FechaCreacion) %>% 
  mutate(MontoEstimado = as.numeric(gsub(",",".",MontoEstimado))) %>%
  mutate(Valor.Total.Ofertado = as.numeric(gsub(",",".",Valor.Total.Ofertado))) %>%
  mutate(is5 = ifelse(Tipo == "LR",1,0)) %>% 
  mutate(is4 = ifelse(Tipo == "LQ",1,0)) %>% 
  mutate(is3 = ifelse(Tipo == "LP",1,0)) %>% 
  mutate(is2 = ifelse(Tipo == "LE",1,0)) %>% 
  mutate(is1 = ifelse(Tipo == "L1",1,0)) %>% 
  group_by(Codigo) %>% mutate(rank = rank(Valor.Total.Ofertado, ties.method = "random")) %>% ungroup() %>% 
  filter(rank <= 2 | Oferta.seleccionada == "Seleccionada") %>% 
  group_by(Codigo) %>% filter(n() > 1)  %>% 
  group_by(Codigo) %>%  mutate(win = Valor.Total.Ofertado[Oferta.seleccionada == "Seleccionada"]) %>% mutate(non_win =Valor.Total.Ofertado[rank==min(rank[Oferta.seleccionada != "Seleccionada"])]) %>%  ungroup() %>% 
  mutate(diff = non_win - win) %>% 
  subset(Oferta.seleccionada == "Seleccionada")

write.csv(final_data, file = paste("BSE/MastersProject/finished_sampled_files/",paste("win_diff",year,".csv", sep = ""),sep = ""))


summary(lm(rel_diff ~ .,final_data))



############################################################################

?rank()

hist(final_data[["diff"]])
hist(final_data[["rel_diff"]])
mean(final_data[["rel_diff"]])

View(data[1:100,])

?abline()
?hline()


plot(final_data$MontoEstimado/60000, final_data$NumeroOferentes)
abline(v = 100)
abline(v = 1000)
abline(v = 2000)

install.packages("rdrobust")
library(rdrobust)

rdd <- rdrobust(y = final_data$NumeroOferentes, x = final_data$MontoEstimado/58000,p = 2, 2000, deriv = 1)
rdd$coef

summary(rdd)

log(120000000)
