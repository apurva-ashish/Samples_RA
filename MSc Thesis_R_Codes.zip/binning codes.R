library(did)
library(tidyverse)
data <- read.csv("C:\\Users\\apurv\\Downloads\\win_diff2012.csv")
data1<-read.csv("C:\\Users\\apurv\\Downloads\\win_diff2011.csv")
data1$utm <- data1$MontoEstimado / 40000
data$utm <- data$MontoEstimado / 38000
trey<-rbind(data,data1)
trey$fecha <- as.Date.character(trey$FechaPublicacion, format = "%Y-%m-%d")
trey$post <- if_else(trey$fecha >= as.Date("2011-12-27"), 1, 0)
trey$treat <- ifelse(trey$utm < 1000, 1,0)
trey$did   <- trey$post * trey$treat
trey$data$utm <- as.numeric(trey$data$utm)
trey$data1$utm <- as.numeric(trey$data1$utm)
trey$bin2<-if_else(trey$utm<100,1,0)
trey$bin2 <- if_else(trey$utm < 200 & trey$utm >= 100, 2, trey$bin2)
trey$bin2 <- if_else(trey$utm < 300 & trey$utm >= 200, 3, trey$bin2)
trey$bin2 <- if_else(trey$utm < 400 & trey$utm >= 300, 4, trey$bin2)
trey$bin2 <- if_else(trey$utm < 500 & trey$utm >= 400, 5, trey$bin2)
trey$bin2 <- if_else(trey$utm < 600 & trey$utm >= 500, 6, trey$bin2)
trey$bin2 <- if_else(trey$utm < 700 & trey$utm >= 600, 7, trey$bin2)
trey$bin2 <- if_else(trey$utm < 800 & trey$utm >= 700, 8, trey$bin2)
trey$bin2 <- if_else(trey$utm < 900 & trey$utm >= 800, 9, trey$bin2)
trey$bin2 <- if_else(trey$utm < 1000 & trey$utm >= 900, 10, trey$bin2)
#trey$bin <- cut(trey$utm, breaks = c(99, 199,1000))
trey$binfactor<-as.factor(trey$bin2)
reg7 <- lm(NumeroOferentes ~ treat+ did*binfactor+post, data = trey)
summary(reg7)
# set up cut-off values 
breaks <- c(0,100,200,300,400,500,600,700,800,900,1000)
tags <- c("[0-100)","[100-200)", "[200-300)", "[300-400)", "[400-500)", "[500-600)","[600-700)", "[700-800)","[800-900)", "[900-1000)")
group_tags <- cut(trey$utm, 
                  breaks=breaks, 
                  include.lowest=TRUE, 
                  right=FALSE, 
                  labels=tags)
# inspect bins
summary(group_tags)
#plot binned regression
coeffs <- lapply(reg7$trey$bin2, coef)
plot(NumeroOferentes ~ treat+ did*binfactor+post, data = trey)
for(i in seq_along(reg7)) {
  abline(coeffs[[10]], col = 10)
}
#This code creates bins based on the size in  the trey dataset, fits separate regression line.

#plot binned data with number of data points in each
ggplot(data = as_tibble(trey), mapping = aes(group_tags)) + 
  geom_bar(fill="black",alpha=0.9) + 
  stat_count(geom="text", aes(label=sprintf("%.2f",..count../length(group_tags))), vjust=-0.5) +
  labs(x='binned size') +theme(axis.text.x = element_text(size =7),panel.grid.major = element_blank(),panel.grid.minor = element_blank() )
 
#polynomial interpolation


