###HOW TO USE####
#create simple folder structure with subfolders: zips, raw_files and finished_sample_files
#Adapt paths below as needed to navigate into folder structure 
#download files for a given year from "https://datos-abiertos.chilecompra.cl/descargas"
#adapt year variable at the top 
#run code

year = 2012

###unzip all files 
for(i in 1:12){
  path <- paste("BSE/Masters Project/zips/",year,"-",i,".zip", sep = "")
  unzip(path, exdir = "BSE/Masters Project/raw_files")
}

t <- data.frame()

###combine months 
for(i in 1:12){
  
  path <- paste("BSE/Masters Project/raw_files/lic_",year,"-",i,".csv", sep ="")
  name <- paste(year,i, sep = "_")
  data <- read.csv(path,  fileEncoding="latin1", sep=";")
  codes <- data[1]
  un_code <- c(unique(codes))[[1]]
  sample <- sample(un_code, size = floor(length(un_code)/100))
  sampled_data <- data[data$Codigo %in% sample,]
  assign(name,sampled_data)
  print(i)
}
#combine all months 
for(i in 1:12){
  name <- paste(year,i,sep = "_")
  month_data <- get(name)
  t <- rbind(t,month_data)
}

#write_final
write.csv(t, file = paste("BSE/Masters Project/finished_sampled_files/",paste(year,"rep_sampled.csv", sep = "_"),sep = ""))


codes

floor(length(un_code)/100)
