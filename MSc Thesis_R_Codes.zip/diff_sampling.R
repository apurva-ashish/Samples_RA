##big files

library(tidyverse)

##### using data.table 
library(data.table)
year = 2022
# create a list of file paths for all the CSV files
file_paths <- sprintf("BSE/Masters Project/raw_files/lic_%s-%02d.csv", year, 1:12)
# read in all the CSV files and combine them into a single data table
data <- rbindlist(lapply(file_paths, fread, sep = ";", encoding = "Latin-1"))

# perform data manipulation using data.table syntax
colnames(data) <- make.names(colnames(data))
final_data <- data %>% 
  mutate(length = FechaCierre - FechaCreacion) %>% 
  mutate(is5 = ifelse(Tipo == "LR",1,0)) %>% 
  mutate(is4 = ifelse(Tipo == "LQ",1,0)) %>% 
  mutate(is3 = ifelse(Tipo == "LP",1,0)) %>% 
  mutate(is2 = ifelse(Tipo == "LE",1,0)) %>% 
  mutate(is1 = ifelse(Tipo == "L1",1,0)) %>% 
  mutate(MontoLineaAdjudica = as.numeric(data[["MontoLineaAdjudica"]])) %>% 
  subset(Oferta.seleccionada == "Seleccionada") %>% 
  subset(Tipo %in% c("LR","LQ","LP","LE","L1")) %>% 
  group_by(Codigo) %>%  filter(n() == 1 )



###does length of bidding window effect number of offers?
summary(lm(NumeroOferentes ~ length, final_data))
# -> no 

###does number of bidders affect profit?
wdata <- data.frame(final_data)

#subset to columns where we can reasonably compute profit

wdata <- wdata %>% 
  subset(Estimacion == 2) %>% 
  mutate(MontoEstimado = as.numeric(gsub(",",".",MontoEstimado))) %>% 
  mutate(profit = (as.numeric(MontoLineaAdjudica) - as.numeric(MontoEstimado )) / as.numeric(MontoEstimado)) %>% 
  subset(MontoEstimado >= 100) %>% 
  subset(as.numeric(MontoLineaAdjudica) < as.numeric(MontoEstimado*20 ))

names <- names(wdata)
nums = c()
for(i in names){
  if(is.numeric(wdata[[i]]) | is.integer(wdata[[i]])){
    nums <- c(nums, i)
  }
}

class(wdata[["FechaCreacion"]])

numdata <- wdata[, c(nums)]
numdata <- numdata[, !colnames(numdata) %in% c("X","Codigo","FechaCreacion","Codigoitem")]
numdata <- numdata %>% 
  select(c("profit","Etapas","EstadoPublicidadOfertas","CantidadReclamos","VisibilidadMonto","MontoEstimado","NumeroOferentes","MontoLineaAdjudica","length")) %>% 
  scale()

numdata <- data.frame(numdata)

summary(lm(profit ~ ., numdata))





