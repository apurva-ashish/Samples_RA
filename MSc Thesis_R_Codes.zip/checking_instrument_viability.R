#format creation date as date
library(tidyverse)

cols <- intersect(names(master),names(data_2013))
#data <- rbind(master[,cols],data_2013[,cols])
data <- master            

data["FechaCreacion"] <- as.numeric(as.Date(data[["FechaCreacion"]]))
data["FechaCierre"] <- as.numeric(as.Date(data[["FechaCierre"]]))
data["FechaInicio"] <- as.numeric(as.Date(data[["FechaInicio"]]))
data["FechaFinal"] <- as.numeric(as.Date(data[["FechaFinal"]]))

#create binary indicator 

#afterreg <- ifelse(data["FechaCreacion"] >= 16657,1,0 )
#colnames(afterreg) <- "afterreg"
#data <- cbind(data, afterreg)
#length var 

data <- data %>% 
  mutate(length = FechaCierre - FechaCreacion) %>% 
  mutate(is5 = ifelse(Tipo == "LR",1,0)) %>% 
  mutate(is4 = ifelse(Tipo == "LQ",1,0)) %>% 
  mutate(is3 = ifelse(Tipo == "LP",1,0)) %>% 
  mutate(is2 = ifelse(Tipo == "LE",1,0)) %>% 
  mutate(is1 = ifelse(Tipo == "L1",1,0)) %>% 
  mutate(MontoLineaAdjudica = as.numeric(data[["MontoLineaAdjudica"]])) %>% 
  subset(Oferta.seleccionada == "Seleccionada") %>% 
  subset(Tipo %in% c("LR","LQ","LP","LE","L1")) 


smallset <- subset(data, is4 == 0 & is5 == 0)
mean(test[["afterreg"]])

test <- subset(data,is4 == 1)


lm1 <- lm(length ~ afterreg, test)

summary(lm1)


mean(smallset[["length"]])

test <- subset(data, is1 ==1 & length < 100)

mean(test[["length"]])

testafter <- subset(test, afterreg == 1)

mean(testafter[["length"]])

summary(lm(length ~ afterreg, test))


##test for effect of length on number of bids? 

summary(lm(NumeroOferentes ~ length, smallset))




#test for 2013 
data["FechaCreacion"] <- as.numeric(as.Date(data[["FechaCreacion"]]))
data["FechaCierre"] <- as.numeric(as.Date(data[["FechaCierre"]]))
data["FechaInicio"] <- as.numeric(as.Date(data[["FechaInicio"]]))
data["FechaFinal"] <- as.numeric(as.Date(data[["FechaFinal"]]))


###

names <- names(data)

nums = c()
for(i in names){
  if(class(data[[i]]) == "integer" | class(data[[i]]) == "numeric" ){
    nums = c(nums,i)
  }
}

class(data[[names[2]]])

numdata <- data[, nums]
numdata <- numdata[, !colnames(numdata) %in% c("X","Codigo","FechaCreacion","Codigoitem")]
summary(lm(afterreg ~ ., data = numdata))



